function login(){

let usuario = document.getElementById("usuario").value;
let clave = document.getElementById("clave").value;

let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

// Usuario administrador por defecto
if(usuario === "admin" && clave === "1234"){
    window.location = "dashboard.html";
    return;
}

let encontrado = usuarios.find(function(u){
    return u.usuario === usuario && u.clave === clave;
});

if(encontrado){
    localStorage.setItem("usuarioActivo", JSON.stringify(encontrado));
    window.location = "dashboard.html";
}else{
    document.getElementById("mensaje").innerHTML = "Usuario o contraseña incorrectos";
}

}