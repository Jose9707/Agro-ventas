const SUPABASE_URL = "https://susjmmluvidogtwclvjw.supabase.co";

const SUPABASE_KEY = "sb_publishable_G7C06sf1hxdE87FUxsqm_Q_t2TWoqXk";

const supabase = window.supabase.createClient(
    SUPABASE_URL,
    SUPABASE_KEY
);