let usuarios = JSON.parse(localStorage.getItem("usuarios")) || [];

mostrarUsuarios();

function guardarUsuario(){

let nombre=document.getElementById("nombre").value;
let usuario=document.getElementById("usuario").value;
let clave=document.getElementById("clave").value;
let rol=document.getElementById("rol").value;

if(nombre=="" || usuario=="" || clave=="" || rol==""){
alert("Complete todos los campos");
return;
}

usuarios.push({
nombre:nombre,
usuario:usuario,
clave:clave,
rol:rol
});

localStorage.setItem("usuarios",JSON.stringify(usuarios));

document.getElementById("nombre").value="";
document.getElementById("usuario").value="";
document.getElementById("clave").value="";
document.getElementById("rol").value="";

mostrarUsuarios();

}

function mostrarUsuarios(){

let tabla=document.getElementById("tablaUsuarios");

tabla.innerHTML="";

usuarios.forEach(function(u){

tabla.innerHTML+=`
<tr>
<td>${u.nombre}</td>
<td>${u.usuario}</td>
<td>${u.rol}</td>
</tr>
`;

});

}